$(document).ready(function() {
    // Smooth scroll for links
    $('a[href^="#"]').on('click', function(event) {
        var target = $(this.getAttribute('href'));
        if (target.length) {
            event.preventDefault();
            $('html, body').animate({
                scrollTop: target.offset().top
            }, 1000);
        }
    });

    // Fade-in and transform effects as elements come into view
    $(window).scroll(function() {
        $('.feature-card, .hero, .bottom-image-section').each(function() {
            var top_of_element = $(this).offset().top;
            var bottom_of_window = $(window).scrollTop() + $(window).height();

            if (bottom_of_window > top_of_element) {
                $(this).addClass('in-view');
            }
        });
    });
});
